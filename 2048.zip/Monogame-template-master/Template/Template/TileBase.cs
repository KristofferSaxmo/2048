﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Template
{
    class TileBase
    {
        public Texture2D TileTex { get; protected set; }
        public List<Vector2> TilePos { get; protected set; }
        public int TileDir { get; protected set; }

        public virtual void ChangeDir(List<Vector2> TilePos, ref int TileDir)
        {
            var keyboardState = Keyboard.GetState();

            if (keyboardState.IsKeyDown(Keys.W)) // Up
            {
                TileDir = 1;
            }
            else if (keyboardState.IsKeyDown(Keys.A)) // Left
            {
                TileDir = 2;
            }
            else if (keyboardState.IsKeyDown(Keys.W)) // Down
            {
                TileDir = 3;
            }
            else if (keyboardState.IsKeyDown(Keys.W)) // Right
            {
                TileDir = 4;
            }
        }

        public virtual void MoveTile(List<Vector2> TilePos, int TileDir)
        {
            if(TileDir == 1) // Move Up
            {
                for(int i = 0; i < TilePos.Count; i++)
                {
                    TilePos[i] = new Vector2(TilePos[i].X, TilePos[i].Y - 5);
                }
            }
            if (TileDir == 2) // Move Left
            {
                for (int i = 0; i < TilePos.Count; i++)
                {
                    TilePos[i] = new Vector2(TilePos[i].X - 5, TilePos[i].Y);
                }
            }
            if (TileDir == 1) // Move Down
            {
                for (int i = 0; i < TilePos.Count; i++)
                {
                    TilePos[i] = new Vector2(TilePos[i].X, TilePos[i].Y + 5);
                }
            }
            if (TileDir == 1) // Move Right
            {
                for (int i = 0; i < TilePos.Count; i++)
                {
                    TilePos[i] = new Vector2(TilePos[i].X + 5, TilePos[i].Y);
                }
            }
        }
        public virtual void MergeTiles(List<Vector2> TilePos, int TileDir)
        {
            for (int i = 0; i < TilePos.Count; i++)
            {
                for (int j = 0; j < TilePos.Count - i; j++)
                {
                    if(TilePos[i] == TilePos[j] && )
                }
            }
        }
    }
}
