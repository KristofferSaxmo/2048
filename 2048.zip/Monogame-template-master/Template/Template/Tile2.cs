﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Template
{
    class Tile2 : TileBase
    {
        public override void ChangeDir(List<Vector2> TilePos, ref int TileDir)
        {
            base.ChangeDir(TilePos, ref TileDir);
        }
        public override void MoveTile(List<Vector2> TilePos, int TileDir)
        {
            base.MoveTile(TilePos, TileDir);
        }
    }
}
